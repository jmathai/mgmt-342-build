# Spring 2027 course materials budget

From: Business Office
To: Bookstore buyer
Date: 2026-11-30

Your purchasing budget for spring 2027 course materials is **$26,000.00**.

This covers everything ordered from publishers and suppliers for the spring
term: new copies, copies bought into the rental pool, digital access codes, and
used copies bought back from students.

The publisher order is committed **2026-12-12**. Spring classes begin
**2027-01-12**.

The figure is firm. There is no mid-semester supplement. If the number does not
work, say so before December 12 and say what you need.
