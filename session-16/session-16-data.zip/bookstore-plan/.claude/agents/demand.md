---
name: demand
description: [ONE SENTENCE. THIS IS THE ONLY PART THAT DECIDES WHETHER THIS AGENT RUNS AT ALL — see Session 10, Part 6. Say what it analyses and when it should be used.]
tools: Read, Write, Bash
---

[WHAT THIS ANALYST IS. One line. "You are the ... analyst for ..."]

## The data you own

- `data/orders-fall.csv`
- `data/enrollment-spring.csv`

## The question you must answer

[HOW MANY UNITS OF EACH TITLE WILL WE SELL IN SPRING, AND IN WHAT FORMAT MIX?]

[THE ATTACH RATE IS THE WAY IN: units sold in fall over fall seats, applied to
projected spring seats. Write the instruction to compute it. Do not write the
number — you do not know it yet, and if you did you would not need this agent.]

[Decide whether the format mix should be the one it observed in fall or
something it is allowed to adjust. Say which.]

## What your memo must contain

[TELL IT TO WRITE `findings/demand.md`. `CLAUDE.md` already sets the four
sections every memo has, so you do not need to repeat them — point at them.]

The title-by-title table has these columns, so the planner can check every
number against its inputs:

| course | title | fall units | fall seats | buy rate | spring seats | projected spring units | fall format mix |

The buy rate is fall units divided by fall seats. The projection is the buy rate
times spring seats. Show both, not just the result.

## What you must not do

[A PROJECTION IS NOT AN ORDER. Who decides how many we buy, and why is it not
this agent?]
