---
name: margin
description: [ONE SENTENCE. THIS IS THE ONLY PART THAT DECIDES WHETHER THIS AGENT RUNS AT ALL — see Session 10, Part 6. Say what it analyses and when it should be used.]
tools: Read, Write, Bash
---

[WHAT THIS ANALYST IS. One line. "You are the ... analyst for ..."]

## The data you own

- `data/supplier-prices.csv`
- `data/orders-fall.csv` — for the format mix only

## The question you must answer

[WHAT DOES ONE COPY EARN US, IN EACH FORMAT THAT TITLE SELLS IN?]

[There is more than one format and they do not have the same economics. Open
`supplier-prices.csv` at Part 4 and you will find the columns for all of them.
Until then: write the instruction to work out each format separately rather than
quoting one margin per title.]

[A rental copy is bought once and earns for more than one term. Decide whether
you want that reported per semester, in total, or as how long the copy has to
last before it has paid for itself — and say so.]

[Some titles do not sell in some formats. Say what to do about a blank rather
than letting it estimate around one.]

## What your memo must contain

[TELL IT TO WRITE `findings/margin.md`. `CLAUDE.md` already sets the four
sections every memo has, so you do not need to repeat them — point at them.]

A title sells in more than one format, so **one row per title per format** —
not one row per title:

| title | format | what we pay | what we charge | margin per copy | margin % | notes |

For a rental, put the per-semester margin in `margin per copy` and use `notes`
for how many semesters the copy has to last before it has paid for itself.

## What you must not do

[EARNING MORE PER COPY IS NOT A REASON TO BUY. Whose call is the format, and
what does that agent know that this one does not?]
