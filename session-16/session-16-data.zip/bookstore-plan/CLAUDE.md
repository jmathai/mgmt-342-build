# Xavier University Bookstore

Shared context. Every agent in this folder reads this file. Anything specific to
one agent's job belongs in that agent's brief, not here.

## The store

One campus store at Xavier University. One buyer, no warehouse, no overflow
storage. We sell course materials in four forms — new copies, used copies bought
back from students, rental copies, and digital access codes — plus a small
amount of branded apparel.

Anything we order and do not sell sits on our floor until it is worthless, or
goes back to the publisher if that publisher takes returns. Not all of them do.

## The decision

What to order for **spring 2027**, title by title: which format, and how many.

- Publisher orders are committed **2026-12-12**.
- Spring classes begin **2027-01-12**.
- We do not know what students actually bought until **late January**, which is
  after most publisher return windows have closed.

Money committed in December cannot be recovered once a return window closes.

## The budget

**$26,000.00** for everything ordered for the spring term. The figure is firm
and there is no mid-semester supplement. Full memo in `data/budget.md`.

## The data

Everything is in `data/`. No agent reads all of it.

**Read only the files your own brief names under "The data you own." Do not open
any other file in `data/`, and do not read another agent's brief or another
agent's memo.** If your brief does not give you what you need to answer your
question, say so in your memo rather than going to look for it.

That rule is what makes the four of you independent. Break it and you are one
agent doing four jobs in one window.

| File | What it holds |
|---|---|
| `orders-fall.csv` | Every line item sold in fall 2026 |
| `enrollment-spring.csv` | Spring sections and projected seats, with fall seats alongside |
| `supplier-prices.csv` | Our cost, list price, format economics, and the publishers' terms |
| `returns-log.csv` | What came back last fall, why, and what it cost us |
| `budget.md` | What we have to spend |

## What a memo contains

Every analyst writes exactly one file to `findings/`, named after itself —
`findings/demand.md`, and so on. Every memo has four sections, in this order:

1. **Method.** The arithmetic, in one paragraph, so somebody can check it.
2. **Title by title.** A table covering every title. Never a summary only. Your
   own brief says what its rows and columns are.
3. **What matters most.** The three findings that would change the order.
4. **What you could not determine.** Say it plainly rather than estimating
   around it.

Write numbers, not adjectives. "Thin margin" is not a finding. "$47.49 a copy,
25%" is a finding.

## The agents

[WHO IS ON THE TEAM. There is a starting point in the session page, Part 2 —
paste it here and change what needs changing.]

## The job

[WHAT THE MAIN AGENT DOES WHEN YOU ASK IT TO RUN THE ANALYSTS, AND WHEN YOU ASK
IT TO BUILD THE PLAN. It does not analyse and it does not decide. It dispatches,
it waits, and it reports what landed.]
